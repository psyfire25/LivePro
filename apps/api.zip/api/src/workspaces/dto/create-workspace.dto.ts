export class CreateWorkspaceDto {
    name: string;
    slug: string;
}
